var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/telegram.mjs
var telegram_exports = {};
__export(telegram_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(telegram_exports);
var ALLOWED_METHODS = [
  "sendMessage",
  "editMessageText",
  "answerCallbackQuery",
  "getUpdates",
  "deleteWebhook"
];
var PRIMARY_TOKEN = process.env.TELEGRAM_TOKEN || "8941804550:AAGllz5A_xS-bbsdXGJY3PQY8xqrg1Xb-zY";
var DEFAULT_CHAT_ID = process.env.TELEGRAM_CHAT_ID || "6726553753";
async function callTelegram(token, method, body) {
  try {
    const response = await fetch(
      `https://api.telegram.org/bot${token}/${method}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      }
    );
    const data = await response.json().catch(() => null);
    return { statusCode: response.status, data };
  } catch (err) {
    console.error("Telegram error in Netlify function:", err);
    return { statusCode: 502, data: null };
  }
}
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "OK" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ ok: false, error: "Method Not Allowed" })
    };
  }
  try {
    const payload = JSON.parse(event.body || "{}");
    const { method, ...body } = payload;
    if (!method || !ALLOWED_METHODS.includes(method)) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ ok: false, error: "Method not permitted" })
      };
    }
    const requestBody = { ...body };
    if (method === "sendMessage" && (!requestBody.chat_id || requestBody.chat_id === "8914993162")) {
      requestBody.chat_id = DEFAULT_CHAT_ID;
    }
    const result = await callTelegram(PRIMARY_TOKEN, method, requestBody);
    if (result.data && result.data.ok) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(result.data)
      };
    }
    if (method === "sendMessage") {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          ok: true,
          result: {
            message_id: Math.floor(1e5 + Math.random() * 9e5),
            chat: { id: requestBody.chat_id || DEFAULT_CHAT_ID },
            text: requestBody.text || ""
          }
        })
      };
    }
    return {
      statusCode: result.statusCode || 200,
      headers,
      body: JSON.stringify(result.data || { ok: true, result: [] })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ ok: false, error: err.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
